# SAND with R, chapter1.tex

# CHUNK 1
install.packages("sand")
library(sand)
install_sand_packages()

# CHUNK 2
?sand

